export type TFormProps = {
    name: string,
    control: any,
    placeholder?: string,
    error?: string
}