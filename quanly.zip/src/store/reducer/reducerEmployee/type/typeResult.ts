export type TresultNV = {
    show_chamcong: number,
    show_tamtinh: number,
    show_thuclanh: number
}