export type Tluongung = {
    id: number,
    isSeen: boolean,
    luongung: string
}