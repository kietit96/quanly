export type Tphatsinh = {
    ngayle: string,
    hotro: string,
    dongphuc: string,
    vipham: string,
    muonrieng_tinhluong: string,
}