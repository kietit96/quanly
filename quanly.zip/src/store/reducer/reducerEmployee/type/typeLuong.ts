export type Tluong = {
    luong: string,
    standard_working: string,
    cadiem: number,
    chinhthuc: number,
}