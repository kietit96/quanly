export type TcheckIfExit = {
    id: number,
    nangxuatlam: string,
    cong: string,
    tienchuyencan: string
}