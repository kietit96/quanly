export enum ActionTypes {
    SET_ACTIVE = "SET_ACTIVE"
}