export enum ActionTypes {
    SET_LOCATION = "SET_LOCATION",
}