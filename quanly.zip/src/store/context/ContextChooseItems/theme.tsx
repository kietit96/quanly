import reducerChosenItem, { initialChooseItem } from "@/store/reducer/reducerChooseItem/reducer";
import { Tchildren } from "@/types";
import { useReducer } from "react";
import ContextChooseItem from "./context";

export default function ThemeContext({ children }: Tchildren) {
    const [state, dispatch] = useReducer(reducerChosenItem, initialChooseItem)
    return (
        <ContextChooseItem.Provider value={[state, dispatch]}>
            {children}
        </ContextChooseItem.Provider>
    )
}