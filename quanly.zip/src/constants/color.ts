const Color = {
    primary: '#946200',
    primary_bg: '#C7A13D',
    primary_light: '#FFC107',
    bg_login_primary: '#FFE787',
    red: '#FF0000',
    green: '#00FF00',
    blue: '#0000FF',
    yellow: '#FFFF00',
    alert_text: "#ff2000",
    primary_text: "#007bff",
    
}

export default Color;