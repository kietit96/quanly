export const blacklistCheck =
    [
        { label: 'Tuyệt đối không nhận', value: '1' },
        { label: 'Cân nhắc khi nhận', value: '2' }
    ]