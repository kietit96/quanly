export const getListChucvu = () => {
    return [
        { value: 0, label: 'Nhân viên' },
        { value: 1, label: 'Cơ động' },
        { value: 2, label: 'Thời vụ' },
        { value: 3, label: 'Đội trưởng' },
    ]
}