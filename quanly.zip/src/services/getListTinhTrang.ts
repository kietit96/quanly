export const getListTinhTrang = () => {
    return [
        { value: 1, label: 'Đang làm việc' },
        { value: 2, label: 'Đã nghỉ' },
        { value: 0, label: 'Bỏ việc / Đuổi việc' },
    ]
}