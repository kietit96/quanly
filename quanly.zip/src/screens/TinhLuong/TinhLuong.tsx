import { View, Text } from 'react-native'

export default function TinhLuong() {
    return (
        <View>
            <Text>TinhLuong</Text>
        </View>
    )
}